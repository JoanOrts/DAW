﻿<!DOCTYPE HTML>
<!--Desarrollo de Aplicaciones Web-->
<!-- Carlos, Joan-->
<html lang="es">
	<head>
		  <meta charset="UTF-8">
		  <title><?php echo $title; ?></title>
		  <meta name="description" content="Pagina web de almacenamiento y difusión de fotos para la asignatura Programación Hipermedia">
		  <meta name="keywords" content="fotos, imagenes, pictures, images, album, pagina web, pictures &amp; images, compartir fotos">
		  <link rel="stylesheet" href="../css/index.css" media="screen">
		  <link rel="stylesheet" href="../css/print.css" media="print">
		  <link rel="alternate stylesheet" href="../css/accesible.css" media="screen" title="Modo Accesible">
	</head>
