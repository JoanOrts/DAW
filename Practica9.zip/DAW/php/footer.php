	
		<footer>
		  <p>Pictures &amp; Images es una web creada por Joan Orts y Carlos Aracil para la asignatura de Desarrollo de Aplicaciones Web de la Universidad de Alicante</p>
		  <p>Copyright 2017</p>
		</footer>
	</body>
</html>
